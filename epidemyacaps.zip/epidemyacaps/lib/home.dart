import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart';

import './main.dart';
import './list.dart';
import './report.dart';
import './account.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.lightBlue,
        title: Text('E-Map'),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.info,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.map,
                color: Colors.white,
              ),
              onPressed: () {}),
        ],
      ),

      // Drawer nav
      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              accountName: Text('Chester Reyes'),
              accountEmail: Text('reyesml@students.national-u.edu.ph'),
              currentAccountPicture: GestureDetector(
                child: new CircleAvatar(
                  backgroundColor: Colors.red,
                  child: Icon(
                    Icons.person_pin,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Account()));
                },
              ),
              decoration: new BoxDecoration(color: Colors.lightBlueAccent),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Report()),
                );
              },
              child: ListTile(
                title: Text('Report'),
                leading: Icon(
                  Icons.add_location,
                  color: Colors.cyan,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EpidemicList()),
                );
              },
              child: ListTile(
                title: Text('Epidemic List'),
                leading: Icon(Icons.format_list_bulleted, color: Colors.cyan),
              ),
            ),
            Divider(
              height: 10,
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Account()),
                );
              },
              child: ListTile(
                title: Text('Account'),
                leading: Icon(Icons.account_circle, color: Colors.cyan),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
              child: ListTile(
                title: Text('Logout'),
                leading: Icon(Icons.perm_identity, color: Colors.cyan),
              ),
            ),
          ],
        ),
      ),

      body: Stack(
        children: <Widget>[
          // TODO: Integrate google maps
          
          /* Container(
            alignment: Alignment(0.0, 0.0),
            child: new FlutterMap(
              options: new MapOptions(minZoom: 0.5, maxZoom: 10.0),
              layers: [
                new TileLayerOptions(
                    tileSize: 1000.0,
                    urlTemplate:
                        "https://www.turkcebilgi.com/uploads/media/harita/harita_manila.png",
                    subdomains: [
                      'a',
                      'b',
                      'c'
                    ] //http://ncr.ntc.gov.ph/wp-content/uploads/2018/08/ncrmapgooglenew.png
                    )
              ],
            ),
          ), */
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Container(
                padding: EdgeInsets.fromLTRB(70.0, 0.0, 70.0, 35.0),
                height: 80.0,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Report()),
                    );
                  },
                  child: Material(
                    borderRadius: BorderRadius.circular(20.0),
                    color: Colors.blue,
                    elevation: 5.0,
                    child: Center(
                      child: Text(
                        'Report',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
