import 'package:numberpicker/numberpicker.dart';
import 'package:flutter/material.dart';

import './main.dart';
import './list.dart';
import './home.dart';
import 'account.dart';

TextEditingController _barangayController = new TextEditingController();
TextEditingController _ageController = new TextEditingController();
TextEditingController _sexController = new TextEditingController();
TextEditingController _symptomsController = new TextEditingController();

enum GenderCharacter { male, female }
GenderCharacter _gender = GenderCharacter.male;

class Report extends StatefulWidget {
  final Widget child;
  Report({Key key, this.child}) : super(key: key);

  _Report createState() => _Report();
}

class _Report extends State<Report> {
  int _currentAgeValue = 0;
  NumberPicker integerNumberPicker;

  void _showSubmit() {
    if (_barangayController.text == '' || _symptomsController.text == '') {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Report Incomplete'),
              content: new Text('Please complete all required datails.'),
              actions: <Widget>[
                new FlatButton(
                  child: new Text('Try again'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                )
              ],
            );
          });
    } else {
      resetState();
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: new Text(''),
              content: new Text('Report Submitted'),
              actions: <Widget>[
                new FlatButton(
                  child: new Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                )
              ],
            );
          });
    }
  }

  _handleGenderChanged(GenderCharacter value) {
    if (value != null) {
      //`setState` will notify the framework that the internal state of this object has changed.
    }
    if (value is GenderCharacter) {
      setState(() => _gender = value);
    }
  }

  _handleValueChanged(num value) {
    if (value != null) {
      //`setState` will notify the framework that the internal state of this object has changed.
    }
    if (value is int) {
      setState(() => _currentAgeValue = value);
    }
  }

  _handleValueChangedExternally(num value) {
    if (value != null) {
      if (value is int) {
        setState(() => _currentAgeValue = value);
      }
    }
    setState(() => _currentAgeValue = value);
    integerNumberPicker.animateInt(value);
  }

  void resetState() {
    _barangayController.clear();
    _symptomsController.clear();
    setState(() {
      integerNumberPicker.animateInt(0);
      _gender = GenderCharacter.male;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      resizeToAvoidBottomInset: false,
      appBar: new AppBar(
        backgroundColor: Colors.lightBlue,
        title: Text(''),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.map,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              })
        ],
      ),

      //Drawer nav
      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              accountName: Text('Chester Reyes'),
              accountEmail: Text('reyesml@students.national-u.edu.ph'),
              currentAccountPicture: GestureDetector(
                child: new CircleAvatar(
                  backgroundColor: Colors.red,
                  child: Icon(
                    Icons.person_pin,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Account()));
                },
              ),
              decoration: new BoxDecoration(color: Colors.lightBlueAccent),
            ),
            InkWell(
              onTap: () {},
              child: ListTile(
                title: Text('Report'),
                leading: Icon(
                  Icons.add_location,
                  color: Colors.cyan,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EpidemicList()),
                );
              },
              child: ListTile(
                title: Text('Epidemic List'),
                leading: Icon(Icons.format_list_bulleted, color: Colors.cyan),
              ),
            ),
            Divider(
              height: 10,
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Account()),
                );
              },
              child: ListTile(
                title: Text('Account'),
                leading: Icon(Icons.account_circle, color: Colors.cyan),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
              child: ListTile(
                title: Text('Logout'),
                leading: Icon(Icons.exit_to_app, color: Colors.cyan),
              ),
            )
          ],
        ),
      ),

      body: Container(
        padding: EdgeInsets.only(top: 25.0, left: 30.0, right: 30.0),
        child: Column(
          children: <Widget>[
            Text(
              'Submit Report',
              style: TextStyle(
                  fontSize: 25.0,
                  color: Colors.black,
                  fontWeight: FontWeight.bold),
            ),
            TextField(
              controller: _barangayController,
              decoration: InputDecoration(
                  labelText: 'Barangay No.',
                  labelStyle: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                  hintText: 'Barangay 404',
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.lightBlue))),
            ),
            ListTile(
                title: Text(
              'Age',
              textAlign: TextAlign.left,
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            )),
            integerNumberPicker = new NumberPicker.integer(
              initialValue: _currentAgeValue,
              minValue: 0,
              maxValue: 99,
              step: 1,
              onChanged: _handleValueChanged,
            ),
            ListTile(
              title: Text(
                'Gender',
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              title: const Text('Male'),
              leading: Radio(
                value: GenderCharacter.male,
                groupValue: _gender,
                onChanged: _handleGenderChanged,
              ),
            ),
            ListTile(
              title: const Text('Female'),
              leading: Radio(
                value: GenderCharacter.female,
                groupValue: _gender,
                onChanged: _handleGenderChanged,
              ),
            ),
            TextField(
              controller: _symptomsController,
              decoration: InputDecoration(
                  labelText: 'Symptoms',
                  labelStyle: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                  hintText: 'Fever',
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.lightBlue))),
            ),
            SizedBox(
              height: 10.0,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.fromLTRB(70.0, 0.0, 70.0, 0.0),
                  height: 40.0,
                  child: GestureDetector(
                    onTap: () {
                      _showSubmit();
                    },
                    child: Material(
                      borderRadius: BorderRadius.circular(20.0),
                      color: Colors.blue,
                      elevation: 5.0,
                      child: Center(
                        child: Text(
                          'Submit',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
