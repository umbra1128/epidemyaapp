import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

import './main.dart';
import './home.dart';
import './report.dart';
import './list.dart';
import 'account.dart';

class ViewList extends StatefulWidget {
  final Widget child;

  ViewList({Key key, this.child}) : super(key: key);

  _ViewList createState() => _ViewList();
}

class _ViewList extends State<ViewList> {
  List<charts.Series<Record, String>> _seriesRecordData;

  _generateData() {
    var chartData = [
      new Record('April', 'Brgy. 662', 2, Colors.yellow),
      new Record('May', 'Brgy. 802', 4, Colors.orangeAccent),
      new Record('June', 'Brgy. 662', 7, Colors.red),
      new Record('July', 'Brgy. 462', 12, Colors.red),
      new Record('Aug', 'Brgy. 461', 5, Colors.orangeAccent),
      new Record('Sept', 'Brgy. 464', 3, Colors.yellow),
    ];

    _seriesRecordData.add(
      charts.Series(
        data: chartData,
        domainFn: (Record record, _) => record.month,
        measureFn: (Record record, _) => record.recordValue,
        colorFn: (Record record, _) =>
            charts.ColorUtil.fromDartColor(record.colorval),
        id: 'Monthly Record',
        labelAccessorFn: (Record row, _) => '${row.record}',
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _seriesRecordData = List<charts.Series<Record, String>>();
    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomPadding: false,
        appBar: new AppBar(
          backgroundColor: Colors.lightBlue,
          title: Text('E-List'),
          actions: <Widget>[
            new IconButton(
                icon: Icon(
                  Icons.map,
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                })
          ],
        ),

        // Drawer nav
        drawer: new Drawer(
          child: new ListView(
            children: <Widget>[
              new UserAccountsDrawerHeader(
                accountName: Text('Chester Reyes'),
                accountEmail: Text('reyesml@students.national-u.edu.ph'),
                currentAccountPicture: GestureDetector(
                  child: new CircleAvatar(
                    backgroundColor: Colors.red,
                    child: Icon(
                      Icons.person_pin,
                      color: Colors.white,
                    ),
                  ),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Account()));
                  },
                ),
                decoration: new BoxDecoration(color: Colors.lightBlueAccent),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Report()),
                  );
                },
                child: ListTile(
                  title: Text('Report'),
                  leading: Icon(
                    Icons.add_location,
                    color: Colors.cyan,
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EpidemicList()),
                  );
                },
                child: ListTile(
                  title: Text('Epidemic List'),
                  leading: Icon(Icons.format_list_bulleted, color: Colors.cyan),
                ),
              ),
              Divider(
                height: 10,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Account()));
                },
                child: ListTile(
                  title: Text('Account'),
                  leading: Icon(Icons.account_circle, color: Colors.cyan),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Login()),
                  );
                },
                child: ListTile(
                  title: Text('Logout'),
                  leading: Icon(Icons.exit_to_app, color: Colors.cyan),
                ),
              ),
            ],
          ),
        ),
        body: Container(
          padding: EdgeInsets.only(top: 20.0, left: 25.0, right: 25.0),
          child: Column(
              //crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Acute Respiratory Infection',
                  style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  'Is an infection that may interfere with cormal breathing. It can affect just your upper respiratory system, which starts at your sinuses and ends at your vocal chords. It can also affect just your lower respiratory system, which starts at your lungs.',
                  style: TextStyle(fontFamily: 'Montserrat', fontSize: 12.0),
                ),
                Divider(
                  height: 15,
                ),
                Text(
                  'Symptoms: ',
                  style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                ),
                new ListTile(
                  leading: new MyBullet(),
                  title: new Text(
                    'Fatigue',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
                new ListTile(
                  leading: new MyBullet(),
                  title: new Text(
                    'Sore Throat',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
                new ListTile(
                  leading: new MyBullet(),
                  title: new Text(
                    'Body Aches',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
                Divider(
                  height: 15,
                ),
                Text(
                  'Monthly Cases: ',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 5,
                ),
                Expanded(
                  child: charts.BarChart(
                    _seriesRecordData,
                    animate: true,
                    animationDuration: Duration(seconds: 2),
                    behaviors: [
                      /* new charts.DatumLegend(
                        outsideJustification:
                            charts.OutsideJustification.endDrawArea,
                        horizontalFirst: true,
                        desiredMaxRows: 1,
                        cellPadding: new EdgeInsets.only(right: 4, bottom: 4),
                        entryTextStyle: charts.TextStyleSpec(
                            color: charts.MaterialPalette.purple.shadeDefault,
                            fontFamily: 'Georgia',
                            fontSize: 10),
                      ), */
                    ],
                  ),
                ),
              ]),
        ));
  }
}

class MyBullet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Container(
      height: 10.0,
      width: 10.0,
      decoration: new BoxDecoration(
        color: Colors.black,
        shape: BoxShape.circle,
      ),
    );
  }
}

class Record {
  String month;
  String record;
  double recordValue;
  Color colorval;

  Record(this.month, this.record, this.recordValue, this.colorval);
}
